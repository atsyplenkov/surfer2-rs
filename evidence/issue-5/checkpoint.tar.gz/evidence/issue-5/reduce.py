#!/usr/bin/env python3
"""THROWAWAY signature-preserving deletion reducer; never edits full fixtures."""
import argparse
import hashlib
import json
import struct
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("basin", type=int, choices=(1, 2))
parser.add_argument("--binary", default="target/release/examples/prototype_basin")
parser.add_argument("--reported", action="store_true", help="retain the reported face's ancestry signature")
args = parser.parse_args()
here = Path(__file__).resolve().parent
source = here.parents[1] / "fixtures/projected" / f"pl_basins-{args.basin}.json"
rings = json.loads(source.read_bytes())
indices = [list(range(len(r))) for r in rings]
points = [[tuple(struct.unpack("<d", struct.pack("<Q", v))[0] for v in p)
           for p in r] for r in rings]
den = max(v.as_integer_ratio()[1] for r in points for p in r for v in p)
ip = [[tuple(v.as_integer_ratio()[0] * (den // v.as_integer_ratio()[1])
             for v in p) for p in r] for r in points]


def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def area(r):
    return sum(a[0]*b[1]-a[1]*b[0] for a, b in zip(r, r[1:]+r[:1]))


def topology(ids):
    """Exact intersections + preserved orientation; contact neighborhoods locked."""
    rs = [[ip[r][i] for i in ix] for r, ix in enumerate(ids)]
    if any(area(r)*area(ip[i]) <= 0 for i, r in enumerate(rs)):
        return False
    es = [(a, b) for r in rs for a, b in zip(r, r[1:]+r[:1])]
    for i, (a, b) in enumerate(es):
        for c, d in es[i+1:]:
            if any(max(a[k], b[k]) < min(c[k], d[k]) or
                   max(c[k], d[k]) < min(a[k], b[k]) for k in (0, 1)):
                continue
            o = cross(a,b,c), cross(a,b,d), cross(c,d,a), cross(c,d,b)
            if o[0]*o[1] < 0 and o[2]*o[3] < 0:
                return False
            hits = {p for p in (a,b,c,d) if cross(a,b,p)==cross(c,d,p)==0
                    and all(min(a[k],b[k])<=p[k]<=max(a[k],b[k]) and
                            min(c[k],d[k])<=p[k]<=max(c[k],d[k]) for k in (0,1))}
            if len(hits)>1 or not hits<=({a,b}&{c,d}):
                return False
    return True


def signature(result):
    if result["status"] != "dcel_error":
        return False
    if args.reported:
        if args.basin == 1:
            return any(b["original_supports"] == [[0,24,25],[0,14,15]]
                       and b["event"]["kind"] == "TriangleCollapse"
                       and b["birth_miss"] > 1e6 for b in result["births"])
        return any(sorted(m["constraints"]) == [[0,595,596],[0,596,597],[0,601,602]]
                   and m["kind"] == "TriangleCollapse" and 0.1 < m["spread"] < 2
                   for m in result["meetings"])
    if args.basin == 1:
        return any(b["original_supports"] == [[0,184,185],[0,186,187]]
                   and b["event"]["kind"] == "SplitOrFlipRefine"
                   and b["birth_miss"] > 1e6 for b in result["births"])
    return any(sorted(m["constraints"]) == [[0,324,325],[0,325,326]]
               and m["kind"] == "TriangleCollapse" and 90 < m["spread"] < 110
               for m in result["meetings"])


protected = set(range(181,189)) if args.basin == 1 else set(range(321,328))
if args.reported:
    protected = set(range(13,26)) if args.basin == 1 else set(range(594,603))
if args.basin == 1:
    protected.update((322,323,324,1235,1236,1237))
process = subprocess.Popen([args.binary], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, text=True, bufsize=1)
attempts, accepted = [], []
start = time.monotonic()


def check(ids):
    request = {"rings":[[rings[r][i] for i in ix] for r,ix in enumerate(ids)],"indices":ids}
    process.stdin.write(json.dumps(request)+"\n")
    process.stdin.flush()
    result = json.loads(process.stdout.readline())
    good = signature(result)
    if good:
        good = topology(ids)
    attempts.append({"n":sum(map(len,ids)), "status":result["status"],
                     "signature_and_topology":good})
    return good, result


assert check(indices)[0]
chunk = max(1, len(indices[0])//2)
while True:
    changed = False
    removable = [v for v in indices[0] if v not in protected]
    for offset in range(0, len(removable), chunk):
        remove = set(removable[offset:offset+chunk])
        candidate = [[v for v in indices[0] if v not in remove], *indices[1:]]
        if len(candidate[0]) < 3:
            continue
        good, result = check(candidate)
        if good:
            indices = candidate
            changed = True
            accepted.append({"indices":indices, "error":result["error"]})
            print(f"basin {args.basin}: {list(map(len,indices))}; attempts={len(attempts)}", flush=True)
    if chunk == 1:
        if not changed:
            break
    else:
        chunk = max(1, chunk//2)

request = {"rings":[[rings[r][i] for i in ix] for r,ix in enumerate(indices)],
           "indices":indices,"trace":True}
process.stdin.write(json.dumps(request)+"\n")
process.stdin.flush()
result = json.loads(process.stdout.readline())
process.stdin.close()
process.wait()
prefix = here / f"basin-{args.basin}-{'reported-' if args.reported else ''}reduced"
prefix.with_suffix(".json").write_text(json.dumps(request,indent=2)+"\n")
prefix.with_suffix(".trace.json").write_text(json.dumps(result)+"\n")
prefix.with_suffix(".reduction.json").write_text(json.dumps({
    "source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
    "binary_sha256":hashlib.sha256(Path(args.binary).read_bytes()).hexdigest(),
    "protected_exterior":sorted(protected), "seconds":time.monotonic()-start,
    "attempts":attempts,"accepted":accepted,
    "minimality":"deletion-1-minimal among unprotected exterior vertices; holes/contact neighborhoods and witness supports locked"
},indent=2)+"\n")
print("FINAL",indices,"seconds",time.monotonic()-start)
