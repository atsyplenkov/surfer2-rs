#!/usr/bin/env python3
"""Independent infinite-line checks for the two split predecessors only."""
import importlib.util
import json
from fractions import Fraction as Q
from pathlib import Path

D = Path(__file__).resolve().parent
S = D.parent
repo = S.parents[2]
spec = importlib.util.spec_from_file_location('certifier', repo/'evidence/issue-5/certify.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
source = json.loads((repo/'fixtures/projected/pl_basins-2.json').read_text())


def build_lines(trace, req):
    rings = req['rings']
    endpoints = [(ring[i],ring[(i+1)%len(ring)]) for ring in rings for i in range(len(ring))]
    lines = {}
    for v in trace['initial']:
        for s in v['supports']:
            if s is None or s['input_edge'] is None:
                continue
            idx=s['input_edge']
            p,q=map(m.decode,endpoints[idx])
            d=tuple(q[k]-p[k] for k in (0,1))
            stored=tuple(map(Q,s['direction']))
            if d != stored:
                assert tuple(-x for x in d)==stored
                p,q=q,p
                d=tuple(-x for x in d)
            assert tuple(map(Q,s['point'])) in (p,q)
            a,b=-d[1],d[0]
            lines[idx]=(a,b,a*p[0]+b*p[1],m.sqrt(a*a+b*b))
    return lines


def desc(i,indices):
    a,b=indices[i],indices[(i+1)%len(indices)]
    return {'local':i,'original_vertices':[a,b], 'is_original_edge': b == (a+1)%len(source[0])}


def analyze(case, steps):
    trace=json.loads((D/(case+'-watched.json')).read_text())
    req=json.loads((S/('basin-2-full-request.ndjson' if case=='full' else 'basin-2-reported-reduced-request.ndjson')).read_text())
    lines=build_lines(trace,req)
    idx=req['indices'][0]
    vertices={v['id']:v for v in trace['vertices']}
    out=[]
    for step in steps:
        e=trace['events'][step]
        assert e['kind']=='SplitOrFlipRefine' and len(e['constraints'])==1
        v=vertices[e['vertices'][e['side']]]
        pair=[s['input_edge'] for s in v['supports']]
        target=next(i for i in lines if [0,idx[i],idx[(i+1)%len(idx)]] == e['constraints'][0])
        assert target not in pair
        t,point=m.arrival(lines,pair,target)
        observed=Q(e['time'])
        stored=[Q(v['origin'][k])+observed*Q(v['velocity'][k]) for k in (0,1)]
        difference=observed-t
        row={'event':e,'parent':v['id'],'parent_supports':[desc(i,idx) for i in pair],
             'target':desc(target,idx),'parent_initial':v['initial'],'parent_birth_time':v['birth_time'],
             'source_arrival_time':t.record(), 'observed_minus_source_time':difference.record(),
             'stored_parent_minus_source_arrival_point':[(m.I(stored[k])-point[k]).record() for k in (0,1)],
             'stored_parent_signed_distance_to_target':m.dist_to_line(lines,target,stored,observed).record()}
        out.append(row)
    return out

result={'full':analyze('full',[2195,2769]), 'reduced':analyze('reduced',[4,9])}
(D/'predecessors.json').write_text(json.dumps(result,indent=2)+'\n')
for case,rows in result.items():
    for r in rows:
        e=r['event']
        print(case,'step',e['step'],'time',e['time'],'side',e['side'],'parent',r['parent'])
        print(' parent support edges',r['parent_supports'],'target',r['target'])
        print(' source arrival time',r['source_arrival_time']['enclosure'])
        print(' observed-source time',r['observed_minus_source_time']['enclosure'])
        print(' stored parent-source meeting', [x['enclosure'] for x in r['stored_parent_minus_source_arrival_point']])
        print(' stored parent signed target distance',r['stored_parent_signed_distance_to_target']['enclosure'])
