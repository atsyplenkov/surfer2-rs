#!/usr/bin/env python3
"""Audit x/y scalar quotients from the recorded final triangle states."""
import json
from fractions import Fraction as Q
from pathlib import Path
D=Path(__file__).resolve().parent
ids=json.loads((D/'representative-indices.json').read_text())

states={}
for name in ('comparison-watched','control'):
    t=json.loads((D/(name+'.json')).read_text())
    v={w['id']:w for w in t['vertices']}
    e=next(e for e in t['events'] if e and e['kind']=='TriangleCollapse' and sorted(e['constraints'])==[[0,595,596],[0,596,597],[0,601,602]])
    pairs={frozenset(ids[s['input_edge']] for s in v[x]['supports']):v[x] for x in e['vertices']}
    states[name]=pairs
    print('\n',name,'actual selected',e['time'])
    for edge,p0,p1 in ((596,(596,601),(595,596)),(595,(595,596),(595,601)),(601,(595,601),(596,601))):
        a=pairs[frozenset(p0)];b=pairs[frozenset(p1)]
        times=[]
        for k in (0,1):
            num=b['origin'][k]-a['origin'][k]
            den=a['velocity'][k]-b['velocity'][k]
            f=num/den
            exact=(Q(b['origin'][k])-Q(a['origin'][k]))/(Q(a['velocity'][k])-Q(b['velocity'][k]))
            times.append((f,exact))
        print(' edge',edge,'x quotient',repr(times[0][0]),'y quotient',repr(times[1][0]),
              'exact x-y seconds',float(times[0][1]-times[1][1]),
              'x denominator',a['velocity'][0]-b['velocity'][0])

a=states['comparison-watched'][frozenset((596,601))]
b=states['control'][frozenset((596,601))]
t=Q(649.3054124144818)
print('\nslow vertex [596,601] comparison/control stored origin:',a['origin'],b['origin'])
print('slow vertex [596,601] comparison/control stored velocity:',a['velocity'],b['velocity'])
print('slow vertex x position difference at comparison event (exact dyadic):',float(Q(a['origin'][0])+t*Q(a['velocity'][0])-Q(b['origin'][0])-t*Q(b['velocity'][0])))
