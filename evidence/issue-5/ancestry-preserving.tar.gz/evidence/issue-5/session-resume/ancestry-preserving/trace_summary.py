#!/usr/bin/env python3
"""Compare original-support 594/595/601 ancestry across three retained traces."""
import json
from pathlib import Path
D=Path(__file__).resolve().parent
S=D.parent


def load(p): return json.loads(p.read_text())


def summarize(path,ids):
    d=load(path); verts={v['id']:v for v in d['vertices']}
    def s(v):
        return [[0,ids[x['input_edge']],ids[(x['input_edge']+1)%len(ids)]] if x is not None and x['input_edge'] is not None else None for x in v['supports']]
    events=[]
    relevant={(0,594,595),(0,595,596),(0,596,597),(0,597,598),(0,600,601),(0,601,602),(0,602,603)}
    for e in d['events']:
        if e and any(tuple(x) in relevant for x in e['constraints']):
            ev={k:e[k] for k in ('step','kind','time','triangle','side','constraints','spread','positions','vertices')}
            ev['states']=[{'id':x,'supports':s(verts[x]),'birth_time':verts[x]['birth_time'],'birth':verts[x]['birth'],
                           'origin_bits':verts[x]['origin_bits'],'velocity_bits':verts[x]['velocity_bits'],
                           'infinite_speed':verts[x]['infinite_speed']} for x in e['vertices']]
            events.append(ev)
    births=[]
    for b in d['births']:
        if any(tuple(x) in relevant for x in b['original_supports'] if x is not None):
            births.append({'id':b['id'],'step':b['step'],'original_supports':b['original_supports'],'birth_time':b['birth_time'],
                           'birth_miss':b['birth_miss'],'event':b['event'],
                           'origin_bits':b['origin_bits'],'velocity_bits':b['velocity_bits']})
    arcs=[]
    for a in d['arcs']:
        if any(d['faces'][i] and tuple(d['faces'][i]) in relevant for i in (a['left'],a['right']) if 0<=i<len(d['faces'])):
            a=dict(a); a['source_faces']=[d['faces'][a[i]] if 0<=a[i]<len(d['faces']) else None for i in ('left','right')]; arcs.append(a)
    return {'status':d['status'],'error':d.get('error'),'failed_constraint':d.get('failed_constraint'),
            'graph':d.get('graph'),'events':events,'births':births,'arcs':arcs}

ids=load(D/'representative-indices.json')
out={'comparison':summarize(D/'comparison-watched.json',ids),
     'control':summarize(D/'control.json',ids),
     'full':summarize(S/'reported-collapse/full-watched.json',list(range(3358))),
     'full_control':summarize(S/'basin-2-full-control.json',list(range(3358)))}
(D/'trace-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for case in ('comparison','control','full','full_control'):
    r=out[case]; print('\n',case,'status',r['status'],'failed_constraint',r['failed_constraint'],'graph',r['graph'])
    for e in r['events']:
        if case in ('full','full_control') and not (370.9<e['time']<371.1 or 649.3<e['time']<649.4): continue
        if case=='control' or 370.9<e['time']<371.1 or 649.3<e['time']<649.4:
            print(' event',e['step'],e['time'],e['kind'],'constraints',e['constraints'],'spread',e['spread'])
            print('  vertex supports',[v['supports'] for v in e['states']])
    for b in r['births']:
        if sorted(x for x in b['original_supports'] if x is not None)==[[0,595,596],[0,601,602]]:
            print(' target child',b['id'],'birth',b['birth_time'],'miss',b['birth_miss'],'event',b['event']['step'],b['event']['kind'],b['event']['constraints'])
