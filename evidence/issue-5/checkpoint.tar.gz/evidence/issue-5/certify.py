#!/usr/bin/env python3
"""Independent rational/interval certificates. No Rust imports or output goldens.

Input binary64 numbers are exact dyadics. Square roots are enclosed by exact
integer squaring on a 2^-192 grid. Interval endpoints propagate outwards through
the complete linear solves; display decimals are rounded outwards as well.
"""
import gzip
import json
import struct
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent


class I:
    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = Q(lo if hi is None else hi)

    def __add__(self, b):
        b = interval(b)
        return I(self.lo+b.lo, self.hi+b.hi)

    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, b):
        return self + -interval(b)

    def __rsub__(self, b):
        return interval(b) + -self

    def __mul__(self, b):
        b = interval(b)
        ends = [x*y for x in (self.lo,self.hi) for y in (b.lo,b.hi)]
        return I(min(ends),max(ends))

    __rmul__ = __mul__

    def __truediv__(self, b):
        b = interval(b)
        assert not b.lo <= 0 <= b.hi, "denominator not certified nonzero"
        return self * I(1/b.hi,1/b.lo)

    def shown(self, digits=20):
        scale = 10**digits
        def f(v):
            return f"{'-' if v<0 else ''}{abs(v)//scale}.{abs(v)%scale:0{digits}d}"
        return [f((self.lo*scale).__floor__()),f((self.hi*scale).__ceil__())]

    def record(self):
        return {"enclosure":self.shown(),
                "exact_width":str(self.hi-self.lo),
                "excludes_zero":not self.lo<=0<=self.hi}


def interval(x):
    return x if isinstance(x,I) else I(x)


def sqrt(q):
    q=Q(q)
    d=1<<192
    k=isqrt(q.numerator*d*d//q.denominator)
    lo=Q(k,d)
    hi=lo if lo*lo==q else Q(k+1,d)
    assert lo*lo<=q<=hi*hi
    return I(lo,hi)


def load(name):
    path=HERE/name
    return json.loads(path.read_bytes() if path.exists() else gzip.decompress(path.with_suffix(path.suffix+".gz").read_bytes()))


def decode(p):
    return tuple(Q(struct.unpack("<d",struct.pack("<Q",v))[0]) for v in p)


def setup(n, trace):
    rings=json.loads((HERE.parents[1]/f"fixtures/projected/pl_basins-{n}.json").read_bytes())
    raw=[p for ring in rings for p in ring]
    endpoints=[(ring[i],ring[(i+1)%len(ring)]) for ring in rings for i in range(len(ring))]
    lines={}
    for v in trace["initial"]:
        for s in v["supports"]:
            if s is None or s["input_edge"] is None:
                continue
            idx=s["input_edge"]
            p,q=map(decode,endpoints[idx])
            d=tuple(q[k]-p[k] for k in (0,1))
            stored=tuple(map(Q,s["direction"]))
            if d==stored:
                pass
            elif tuple(-x for x in d)==stored:
                p,q=q,p
                d=tuple(-x for x in d)
            else:
                raise AssertionError("stored support is not the original constraint")
            assert tuple(map(Q,s["point"])) in (p,q)
            a,b=-d[1],d[0]
            lines[idx]=(a,b,a*p[0]+b*p[1],sqrt(a*a+b*b))
    return lines


def motion(lines, pair):
    a,b,c,l=lines[pair[0]]
    d,e,f,m=lines[pair[1]]
    det=a*e-d*b
    assert det != 0
    return ((I(c*e-f*b)/det,I(a*f-d*c)/det),
            ((l*e-m*b)/det,(m*a-l*d)/det))


def arrival(lines, pair, other):
    o,v=motion(lines,pair)
    a,b,c,l=lines[other]
    t=(c-a*o[0]-b*o[1])/(a*v[0]+b*v[1]-l)
    return t,[o[k]+t*v[k] for k in (0,1)]


def pair(v):
    return [s["input_edge"] for s in v["supports"]]


def dist_to_line(lines, support, position, time):
    a,b,c,l=lines[support]
    return (a*position[0]+b*position[1]-c-l*time)/l


def inspect(n, step, label):
    trace=load(f"pl_basins-{n}-scan.json")
    lines=setup(n,trace)
    vertices={v["id"]:v for v in trace["vertices"]}
    e=trace["events"][step]
    vv=[vertices[i] for i in e["vertices"]]
    result={"label":label,"basin":n,"event":e,"vertices":vv}
    result["source_positions_at_observed_time"]=[]
    for v in vv:
        o,speed=motion(lines,pair(v))
        pos=[o[k]+Q(e["time"])*speed[k] for k in (0,1)]
        result["source_positions_at_observed_time"].append([x.record() for x in pos])
    if label=="early":
        edge=184 if n==1 else 324
        opposite=vv[e["side"]]
        o,speed=motion(lines,pair(opposite))
        pos=[o[k]+Q(e["time"])*speed[k] for k in (0,1)]
        residual=dist_to_line(lines,edge,pos,Q(e["time"]))
        hit,_=arrival(lines,pair(opposite),edge)
        result["opposite_line_hit"]=hit.record()
        result["opposite_distance_at_event"]=residual.record()
        assert hit.hi<0 and residual.hi < -50
        # Near-four-support junction: two competing original constraints.
        ids=[181,182,184,185] if n==1 else [321,322,324,325]
        ta,pa=arrival(lines,[ids[1],ids[2]],ids[0])
        tb,pb=arrival(lines,[ids[1],ids[2]],ids[3])
        delta=ta-tb
        assert delta.lo>0
        result["competing_original_events"]={
            "shared_pair":ids[1:3],"third_a":ids[0],"third_b":ids[3],
            "a_time":ta.record(),"b_time":tb.record(),
            "a_minus_b":delta.record(),"a_point":[x.record() for x in pa],
            "b_point":[x.record() for x in pb],
        }
        # The fabricated successor's later mathematical intersection is NOT
        # the physical next event once the earlier edge has retired.
        tc,_=arrival(lines,[ids[0],ids[2]],ids[3])
        result["post_wrong_order_support_meeting"]=tc.record()
    elif n==1:
        # The 51.7m triangle stop precedes the famous megametre birth miss.
        assert e["kind"]=="TriangleCollapse" and 50<e["spread"]<53
        v=vv[0]
        other=vv[2]
        o,speed=motion(lines,pair(v))
        oo,ss=motion(lines,pair(other))
        result["certified_source_separation_xy"]=[
            (o[k]+Q(e["time"])*speed[k]-oo[k]-Q(e["time"])*ss[k]).record()
            for k in (0,1)]
    else:
        # Three active constraints define one reference point/time, but do not
        # license a min of inconsistent endpoint times.
        time,point=arrival(lines,[595,596],601)
        result["three_support_time"]=time.record()
        result["three_support_point"]=[x.record() for x in point]
        result["observed_minus_reference_time"]=(Q(e["time"])-time).record()
        for v in vv:
            if set(pair(v))=={595,601}:
                rounded=[Q(v["origin"][k])+Q(e["time"])*Q(v["velocity"][k]) for k in (0,1)]
                result["fast_stored_minus_reference_point"]=[(rounded[k]-point[k]).record() for k in (0,1)]
                o,speed=motion(lines,pair(v))
                result["fast_origin_error"]=[(Q(v["origin"][k])-o[k]).record() for k in (0,1)]
                result["fast_velocity_error"]=[(Q(v["velocity"][k])-speed[k]).record() for k in (0,1)]
    return result


if __name__=="__main__":
    results=[inspect(1,15,"early"),inspect(2,53,"early"),
             inspect(1,1966,"reported"),inspect(2,2770,"reported")]
    (HERE/"certificates.json").write_text(json.dumps(results,indent=2)+"\n")
    for r in results:
        print(r["basin"],r["label"])
        for key in ("opposite_distance_at_event","opposite_line_hit",
                    "observed_minus_reference_time","certified_source_separation_xy",
                    "fast_stored_minus_reference_point"):
            if key in r:
                print(key,r[key])
        if "competing_original_events" in r:
            print("certified event-order difference",r["competing_original_events"]["a_minus_b"])
