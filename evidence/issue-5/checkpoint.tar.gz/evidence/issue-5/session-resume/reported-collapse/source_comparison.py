#!/usr/bin/env python3
"""Throwaway: compare just the reported 595/596/601 witness to source lines.

Uses the existing interval functions, never writes outside this directory.
"""
import importlib.util
import json
from fractions import Fraction as Q
from pathlib import Path

D = Path(__file__).resolve().parent
S = D.parent
repo = S.parents[2]
spec = importlib.util.spec_from_file_location('existing_certifier', repo/'evidence/issue-5/certify.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
full = json.loads((D/'full-watched.json').read_text())
reduced = json.loads((D/'reduced-watched.json').read_text())
request = json.loads((S/'basin-2-reported-reduced-request.ndjson').read_text())
source = json.loads((repo/'fixtures/projected/pl_basins-2.json').read_text())
ids = request['indices'][0]
assert all(p == source[0][i] for p, i in zip(request['rings'][0], ids))
assert ids[:9] == list(range(594, 603))
lines = m.setup(2, full)

# Confirm the source identities and stored orientation in the reduced and full
# initial states, without assuming reduced input-edge numbering equals original.
def support_by_source(trace, remap):
    out = {}
    for vert in trace['initial']:
        for s in vert['supports']:
            if s is not None and s['input_edge'] is not None:
                k = remap(s['input_edge'])
                if k in (595, 596, 601):
                    attrs = (s['point'], s['direction'], s['normal'], s['weight'])
                    if k in out:
                        assert out[k] == attrs
                    out[k] = attrs
    return out

fs = support_by_source(full, lambda x: x)
rs = support_by_source(reduced, lambda x: ids[x])
assert set(fs) == set(rs) == {595, 596, 601}
assert fs == rs


def pos(origin, velocity, t):
    return [Q(origin[k])+Q(t)*Q(velocity[k]) for k in (0, 1)]


def report(trace, remap, event_step):
    ev = trace['events'][event_step]
    assert ev['kind'] == 'TriangleCollapse'
    vertices = {v['id']: v for v in trace['vertices']}
    births = {v['id']: v for v in trace['births']}
    answer = {'event': ev, 'vertices': []}
    for vid in ev['vertices']:
        v = vertices[vid]
        pair = [remap(s['input_edge']) for s in v['supports']]
        assert set(pair) <= {595, 596, 601}
        assert v['infinite_speed'] == 'None'
        o, vel = m.motion(lines, pair)
        row = {'id': vid, 'supports': pair, 'birth_time': v['birth_time'],
               'birth': v['birth'], 'origin': v['origin'], 'velocity': v['velocity'],
               'velocity_error': [(m.I(Q(v['velocity'][k]))-vel[k]).record() for k in (0,1)],
               'creation_event': births.get(vid,{}).get('event'), 'samples': []}
        for label, t in [('birth', v['birth_time']), ('triangle', ev['time'])]:
            stored = pos(v['origin'], v['velocity'], t)
            expected = [o[k] + vel[k]*Q(t) for k in (0,1)]
            samp = {'label': label, 'time': t,
                    'stored_minus_source_intersection': [(m.I(stored[k])-expected[k]).record() for k in (0,1)],
                    'stored_signed_support_residuals': [m.dist_to_line(lines,s,stored,Q(t)).record() for s in pair]}
            if label == 'birth':
                birth = [Q(v['birth'][k]) for k in (0,1)]
                samp['stored_minus_recorded_birth'] = [m.I(stored[k]-birth[k]).record() for k in (0,1)]
                samp['recorded_birth_minus_source_intersection'] = [(m.I(birth[k])-expected[k]).record() for k in (0,1)]
                samp['birth_signed_support_residuals'] = [m.dist_to_line(lines,s,birth,Q(t)).record() for s in pair]
            row['samples'].append(samp)
        answer['vertices'].append(row)
    return answer

out = {'fixture_bits_match_reduction': True, 'mapped_support_records_equal': True,
       'support_records': fs, 'full': report(full,lambda x:x,2770),
       'reduced': report(reduced,lambda x:ids[x],10)}
(D/'source-comparison.json').write_text(json.dumps(out, indent=2)+'\n')
for case in ('full','reduced'):
    print('\n', case, 'event', out[case]['event']['time'])
    for v in out[case]['vertices']:
        print(' vertex', v['id'], 'supports', v['supports'], 'birth',v['birth_time'])
        print('  velocity_error', [x['enclosure'] for x in v['velocity_error']])
        for s in v['samples']:
            print(' ',s['label'])
            for key in ('stored_minus_recorded_birth','recorded_birth_minus_source_intersection',
                        'birth_signed_support_residuals','stored_minus_source_intersection',
                        'stored_signed_support_residuals'):
                if key in s:
                    print('  ',key,[x['enclosure'] for x in s[key]])
