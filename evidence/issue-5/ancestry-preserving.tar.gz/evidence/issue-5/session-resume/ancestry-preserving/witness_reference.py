#!/usr/bin/env python3
"""Source-line and stored-motion checks for the 12-vertex witness only."""
import importlib.util
import json
from fractions import Fraction as Q
from pathlib import Path
D=Path(__file__).resolve().parent
S=D.parent
repo=S.parents[2]
spec=importlib.util.spec_from_file_location('existing_certifier',repo/'evidence/issue-5/certify.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
full=json.loads((S/'reported-collapse/full-watched.json').read_text())
witness=json.loads((D/'comparison-watched.json').read_text())
control=json.loads((D/'control.json').read_text())
full_control=json.loads((S/'basin-2-full-control.json').read_text())
ids=json.loads((D/'representative-indices.json').read_text())
lines=m.setup(2,full)

# The independent source-support intersection must lie inside the source-line
# segment with endpoint pairs 601/602 and 601/596. It does not establish that
# the wavefront edge has survived all earlier events.
t, p=m.arrival(lines,[594,595],601)
o0,v0=m.motion(lines,[601,602]); o1,v1=m.motion(lines,[601,596])
a=[o0[k]+v0[k]*t for k in (0,1)]; b=[o1[k]+v1[k]*t for k in (0,1)]
alpha=(p[0]-a[0])/(b[0]-a[0])
assert alpha.lo>0 and alpha.hi<1

def eval_case(trace,remap):
    verts={v['id']:v for v in trace['vertices']}
    def pair(v): return [remap(s['input_edge']) for s in v['supports']]
    births=[b for b in trace['births'] if sorted(x for x in b['original_supports'] if x is not None)==[[0,595,596],[0,601,602]] and b['event']['kind']=='SplitOrFlipRefine' and b['event']['constraints']==[[0,601,602]]]
    assert len(births)==1
    birth=births[0]; ev=birth['event']; parent=verts[ev['vertices'][ev['side']]]
    assert set(pair(parent))=={594,595}
    target_states=[verts[x] for i,x in enumerate(ev['vertices']) if i!=ev['side']]
    assert {frozenset(pair(v)) for v in target_states}=={frozenset((601,602)),frozenset((601,596))}
    final=next(e for e in trace['events'] if e and e['kind']=='TriangleCollapse' and sorted(e['constraints'])==[[0,595,596],[0,596,597],[0,601,602]] and birth['id'] in e['vertices'])
    row={'birth_event':ev,'birth_miss':birth['birth_miss'],'parent_pairs':[pair(parent)]+[pair(v) for v in target_states],
         'child_id':birth['id'],'final_event':final,'status':trace['status'],'graph':trace.get('graph'),'samples':[]}
    for index,vid in enumerate(final['vertices']):
        v=verts[vid]; supports=pair(v); o,speed=m.motion(lines,supports)
        assert v['infinite_speed']=='None'
        ktime=Q(final['time']); stored=[Q(v['origin'][k])+ktime*Q(v['velocity'][k]) for k in (0,1)]
        expected=[o[k]+ktime*speed[k] for k in (0,1)]
        rounding=[stored[k]-Q(final['positions'][index][k]) for k in (0,1)]
        btime=Q(v['birth_time']); bp=[Q(v['birth'][k]) for k in (0,1)]
        atbirth=[Q(v['origin'][k])+btime*Q(v['velocity'][k]) for k in (0,1)]
        item={'id':vid,'support_pair':supports,'origin_bits':v['origin_bits'],'velocity_bits':v['velocity_bits'],
              'birth_time':v['birth_time'],'birth_bits':v['birth_bits'],
              'birth_replay_minus_recorded':[m.I(atbirth[k]-bp[k]).record() for k in (0,1)],
              'stop_stored_minus_source':[(m.I(stored[k])-expected[k]).record() for k in (0,1)],
              'binary64_position_eval_error':[m.I(rounding[k]).record() for k in (0,1)]}
        row['samples'].append(item)
    row['relevant_arcs']=[{'start':a['start'],'end':a['end'],'start_time':a['start_time'],'end_time':a['end_time'],
                           'source_faces':[trace['faces'][a['left']],trace['faces'][a['right']]],'traced_vertex':a['traced_vertex']}
                          for a in trace['arcs'] if a['traced_vertex'] in final['vertices']]
    return row

out={'reference_hit_time':t.record(),'reference_hit_point':[q.record() for q in p],
     'reference_segment_fraction':alpha.record(),
     'comparison':eval_case(witness,lambda x:ids[x]),'full':eval_case(full,lambda x:x),
     'control':eval_case(control,lambda x:ids[x]),'full_control':eval_case(full_control,lambda x:x)}
for ca,cb in (('comparison','full'),('control','full_control')):
    A=out[ca];B=out[cb]
    assert A['birth_event']['time']==B['birth_event']['time']
    assert A['final_event']['time']==B['final_event']['time']
    assert A['final_event']['spread']==B['final_event']['spread']
    amap={tuple(sorted(x['support_pair'])):x for x in A['samples']}
    bmap={tuple(sorted(x['support_pair'])):x for x in B['samples']}
    assert amap.keys()==bmap.keys()
    for pair in amap:
        for field in ('origin_bits','velocity_bits','birth_time','birth_bits'):
            assert amap[pair][field]==bmap[pair][field],(ca,cb,pair,field)
(D/'witness-reference.json').write_text(json.dumps(out,indent=2)+'\n')
print('reference source parent hit time:',out['reference_hit_time']['enclosure'])
print('reference source segment fraction:',out['reference_segment_fraction']['enclosure'])
print('matching full/witness birth and final times, spreads, and stored vertex bits verified for both revisions')
for name in ('comparison','control','full','full_control'):
    r=out[name]; print('\n',name,'birth=',r['birth_event']['time'],'birth_miss=',r['birth_miss'],'stop=',r['final_event']['time'],'spread=',r['final_event']['spread'],'status=',r['status'],'graph=',r['graph'])
    for v in r['samples']:
        print(' supports=',v['support_pair'],'birth_replay=',[x['enclosure'] for x in v['birth_replay_minus_recorded']],
              'stop_minus_source=',[x['enclosure'] for x in v['stop_stored_minus_source']],
              'linear_evaluation_error=',[x['enclosure'] for x in v['binary64_position_eval_error']])
    for a in r['relevant_arcs']:
        print(' arc',a)
