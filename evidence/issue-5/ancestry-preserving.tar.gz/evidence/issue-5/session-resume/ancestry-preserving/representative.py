#!/usr/bin/env python3
"""Throwaway, bounded representative reconstruction (no production changes)."""
import hashlib
import json
import math
import struct
import subprocess
import time
from pathlib import Path

D = Path(__file__).resolve().parent
S = D.parent
repo = S.parents[2]
fixture = repo/'fixtures/projected/pl_basins-2.json'
binary = S/'target/release/examples/prototype_basin'
rings = json.loads(fixture.read_text())
ring = rings[0]
assert len(rings)==1 and len(ring)==3358
assert hashlib.sha256(fixture.read_bytes()).hexdigest() == '1923b3261f191ba581bfca71d9a244dcc08dd769143a2bbce2506743cdb4e77a'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '1add446a198f4dbb7538bf243ce02db96fc4a7d1c2b216c9dc6f51c76bc8250c'

def decode(p):
    return tuple(struct.unpack('<d',struct.pack('<Q',x))[0] for x in p)

# Convert all input dyadics to a common exact integer grid.
points = [decode(p) for p in ring]
den = max(x.as_integer_ratio()[1] for p in points for x in p)
ip = [tuple(x.as_integer_ratio()[0]*(den//x.as_integer_ratio()[1]) for x in p) for p in points]

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def area(rs):
    return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(rs,rs[1:]+rs[:1]))

def simple(ids):
    p=[ip[i] for i in ids]
    if len(p)<3 or len(set(p))!=len(p) or area(p)*area(ip)<=0:
        return False
    edges=list(zip(p,p[1:]+p[:1]))
    def on(a,b,p):
        return cross(a,b,p)==0 and all(min(a[k],b[k])<=p[k]<=max(a[k],b[k]) for k in (0,1))
    for i,(a,b) in enumerate(edges):
        for c,d in edges[i+1:]:
            if any(max(a[k],b[k])<min(c[k],d[k]) or max(c[k],d[k])<min(a[k],b[k]) for k in (0,1)):
                continue
            o=(cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b))
            if o[0]*o[1]<0 and o[2]*o[3]<0:
                return False
            hits={q for q in (a,b,c,d) if on(a,b,q) and on(c,d,q)}
            if len(hits)>1 or not hits<=({a,b}&{c,d}):
                return False
    return True

def mapped_supports(v,ids):
    return [[0,ids[s['input_edge']],ids[(s['input_edge']+1)%len(ids)]] if s is not None and s['input_edge'] is not None else None for s in v['supports']]

def finite_hit(e):
    i=e['side']
    if i not in (0,1,2): return None
    q=e['positions'][i]; a=e['positions'][(i+1)%3]; b=e['positions'][(i+2)%3]
    v=(b[0]-a[0],b[1]-a[1]); w=(q[0]-a[0],q[1]-a[1])
    len2=v[0]**2+v[1]**2
    if len2==0: return None
    t=(w[0]*v[0]+w[1]*v[1])/len2
    dist=abs(v[0]*w[1]-v[1]*w[0])/math.sqrt(len2)
    return {'tparam':t,'normal_distance':dist}

def inspect(ids,out):
    rec={'status':out['status'],'error':out.get('error'),'failed_constraint':out.get('failed_constraint'),'ancestry':False,'final':False}
    if not isinstance(out.get('vertices'),list): return rec
    vs={v['id']:v for v in out['vertices']}
    for b in out['births']:
        if sorted(x for x in b['original_supports'] if x is not None)!=[[0,595,596],[0,601,602]]: continue
        e=b['event']
        if e['kind']!='SplitOrFlipRefine' or e['constraints']!=[[0,601,602]]: continue
        parent=vs[e['vertices'][e['side']]]
        p=sorted(x for x in mapped_supports(parent,ids) if x is not None)
        if p!=[[0,594,595],[0,595,596]]: continue
        hit=finite_hit(e)
        if not hit or not 0.01<hit['tparam']<0.99 or hit['normal_distance']>1e-4: continue
        finals=[z for z in out['events'] if z and z['kind']=='TriangleCollapse' and sorted(z['constraints'])==[[0,595,596],[0,596,597],[0,601,602]] and b['id'] in z['vertices']]
        rec.update({'ancestry':True,'parent_step':e['step'],'parent_time':e['time'],'parent_supports':p,'hit':hit,'child_id':b['id'],'birth_miss':b['birth_miss']})
        if finals:
            f=finals[0]
            rec.update({'final':True,'final_step':f['step'],'final_time':f['time'],'spread':f['spread']})
            rec['matches_signature']=out['status']=='dcel_error' and out.get('failed_constraint')==[0,601,602] and 0.1<f['spread']<2
        return rec
    return rec

base=set(range(594,603))|{1143,3151}
candidates=[('base',sorted(base))]
for n in (1,2,4,8,16,32,64,128,256,512):
    candidates.append((f'extend-after-{n}',sorted(base|set(range(603,603+n)))))
for n in (1,2,4,8,16,32,64,128):
    candidates.append((f'extend-before-{n}',sorted(base|set(range(594-n,594)))))
for before,after in ((1,1),(4,4),(8,8),(16,16),(32,32),(64,64),(128,128)):
    candidates.append((f'both-{before}-{after}',sorted(base|set(range(594-before,594))|set(range(603,603+after)))))

start=time.monotonic(); records=[]; count=0
for name,ids in candidates:
    if time.monotonic()-start>180 or count>=300: break
    s0=time.monotonic()
    valid=simple(ids)
    r={'candidate':name,'n':len(ids),'simple_exact':valid}
    if valid:
        req={'rings':[[ring[i] for i in ids]],'indices':[ids],'trace':True}
        proc=subprocess.run([str(binary)],input=json.dumps(req)+'\n',text=True,capture_output=True,timeout=20)
        count+=1
        if proc.returncode!=0:
            r.update({'process_exit':proc.returncode,'stderr':proc.stderr[-1000:]})
        else:
            out=json.loads(proc.stdout)
            r.update(inspect(ids,out))
            if r.get('matches_signature'):
                (D/'representative-request.ndjson').write_text(json.dumps(req,separators=(',',':'))+'\n')
                (D/'representative-trace.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
                (D/'representative-indices.json').write_text(json.dumps(ids,indent=2)+'\n')
    r['seconds']=round(time.monotonic()-s0,6); records.append(r)
    print(json.dumps(r),flush=True)
    if r.get('matches_signature'): break
summary={'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runner_calls':count,'total_seconds':time.monotonic()-start,'candidates':records}
(D/'representative-results.json').write_text(json.dumps(summary,indent=2)+'\n')
