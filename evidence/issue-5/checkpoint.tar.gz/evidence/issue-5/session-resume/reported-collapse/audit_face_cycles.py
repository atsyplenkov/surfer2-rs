#!/usr/bin/env python3
"""Audit the watched target face's printed next/prev links, not whole DCELs."""
import re
from pathlib import Path
D = Path(__file__).resolve().parent
for name,face in [('reduced-watched',5),('reduced-retime',5),('full-watched',600),('full-retime',600)]:
    group=False
    root=None
    edges={}
    for line in (D/(name+'.log')).read_text().splitlines():
        match=re.search(r'emitted-face face=(\d+) source=.* root=(None|Some\(HalfEdgeId\((\d+)\)\))',line)
        if match:
            if group:
                break
            group=int(match.group(1))==face
            if group:
                root=None if match.group(2)=='None' else int(match.group(3))
            continue
        if group:
            m=re.search(r'halfedge id=(\d+) .* next=HalfEdgeId\((\d+)\) prev=HalfEdgeId\((\d+)\) geometry=(\w+)',line)
            if m:
                edges[int(m[1])]=(int(m[2]),int(m[3]),m[4])
    if not edges:
        raise RuntimeError('missing target face')
    visited=[]
    cur=root
    while cur is not None and cur in edges and cur not in visited:
        visited.append(cur)
        cur=edges[cur][0]
    closed=cur==root if root is not None else False
    reciprocal=all(n in edges and p in edges and edges[n][1]==e and edges[p][0]==e for e,(n,p,_) in edges.items())
    print(name,'face',face,'root',root,'owned',len(edges),'visited',len(visited),
          'closed',closed,'reciprocal',reciprocal,'all_reached',set(visited)==set(edges),
          'infinity_chords',[(e,x[0]) for e,x in edges.items() if x[2]=='InfinityChord'])
