#!/usr/bin/env python3
"""Check corresponding original-support states in the two selected splits."""
import json
from pathlib import Path
D=Path(__file__).resolve().parent
s=json.loads((D/'trace-summary.json').read_text())
for small_step,full_step in ((4,2195),(6,2769),(7,2770)):
    a=next(e for e in s['comparison']['events'] if e['step']==small_step)
    b=next(e for e in s['full']['events'] if e['step']==full_step)
    assert a['kind']==b['kind'] and a['time']==b['time'] and sorted(a['constraints'])==sorted(b['constraints'])
    def states(e): return {tuple(sorted(tuple(x) for x in v['supports'] if x is not None)):v for v in e['states']}
    aa,bb=states(a),states(b)
    assert aa.keys()==bb.keys()
    for pair in aa:
        for field in ('origin_bits','velocity_bits','birth_time','birth','infinite_speed'):
            assert aa[pair][field]==bb[pair][field],(small_step,full_step,pair,field)
    print('witness step',small_step,'full step',full_step,'kind',a['kind'],'time',a['time'],'support-state bits and births equal')
