#!/usr/bin/env python3
"""Compare stored slow motion with the two read-only source formulas."""
import json, math
from pathlib import Path
D=Path(__file__).resolve().parent
ids=json.loads((D/'representative-indices.json').read_text())

def intersect(p0,d0,p1,d1):
    det=d0[0]*d1[1]-d0[1]*d1[0]
    x=p1[0]-p0[0]; y=p1[1]-p0[1]
    s=(x*d1[1]-y*d1[0])/det
    return [p0[0]+s*d0[0],p0[1]+s*d0[1]]

def plus(a,b): return [a[0]+b[0],a[1]+b[1]]

for name in ('comparison-watched','control'):
    t=json.loads((D/(name+'.json')).read_text())
    e=next(e for e in t['events'] if e and e['kind']=='TriangleCollapse' and sorted(e['constraints'])==[[0,595,596],[0,596,597],[0,601,602]])
    verts={v['id']:v for v in t['vertices']}
    v=next(verts[i] for i in e['vertices'] if set(ids[s['input_edge']] for s in verts[i]['supports'])=={596,601})
    a,b=v['supports']; p0=intersect(a['point'],a['direction'],b['point'],b['direction'])
    p1=intersect(plus(a['point'],a['normal']),a['direction'],plus(b['point'],b['normal']),b['direction'])
    sub=[p1[i]-p0[i] for i in (0,1)]
    norm=intersect(a['normal'],a['direction'],b['normal'],b['direction'])
    delta=math.dist(sub,norm); scale=max(math.hypot(*sub),math.hypot(*norm),1)
    print(name,'origin',v['origin'],'stored velocity',v['velocity'])
    print(' subtracted',sub,'normal',norm,'relative difference',delta/scale)
    print(' stored_equals_subtracted',v['velocity']==sub,'stored_equals_normal',v['velocity']==norm)
    assert v['velocity']==(norm if name=='comparison-watched' else sub)
